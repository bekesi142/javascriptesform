function submit(){

    document.getElementById('kapottnev').innerHTML = document.getElementById('beirtneve').value;
    document.getElementById('kapottcim').innerHTML = document.getElementById('beirtcime').value;
    document.getElementById('kapottszam').innerHTML = document.getElementById('beirtszama').value;
}

